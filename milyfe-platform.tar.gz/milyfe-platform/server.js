const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const COOKIE = 'ml_session';
const SESSION_DAYS = 7;
const IS_PROD = process.env.NODE_ENV === 'production';

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], sessions: [], agenda: [], assemblies: {}, invites: [], events: [], audit: [] }, null, 2));
}

const MIME = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.png':'image/png', '.jpg':'image/jpeg', '.svg':'image/svg+xml', '.json':'application/json; charset=utf-8' };
const rate = new Map();

function db(){ return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
function save(d){ fs.writeFileSync(DB_FILE, JSON.stringify(d, null, 2)); }
function id(prefix='id'){ return prefix + '_' + crypto.randomBytes(10).toString('hex'); }
function now(){ return new Date().toISOString(); }
function normEmail(e){ return String(e || '').trim().toLowerCase(); }
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')){
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return { salt, hash };
}
function checkPassword(password, salt, stored){
  const hash = crypto.scryptSync(String(password), salt, 64);
  const other = Buffer.from(stored, 'hex');
  return hash.length === other.length && crypto.timingSafeEqual(hash, other);
}
function parseCookies(req){
  const out = {}; String(req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if(i > -1) out[p.slice(0,i).trim()] = decodeURIComponent(p.slice(i+1)); });
  return out;
}
function cookieHeader(name, value, opts={}){
  const parts = [`${name}=${encodeURIComponent(value)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax'];
  if (opts.maxAge !== undefined) parts.push(`Max-Age=${opts.maxAge}`);
  if (IS_PROD) parts.push('Secure');
  return parts.join('; ');
}
function send(res, status, body, headers={}){ res.writeHead(status, headers); res.end(body); }
function json(res, status, obj, headers={}){ send(res, status, JSON.stringify(obj), { 'Content-Type':'application/json; charset=utf-8', ...headers }); }
function redirect(res, to){ send(res, 302, '', { Location: to }); }
function notFound(res){ send(res, 404, 'Not found', { 'Content-Type':'text/plain; charset=utf-8' }); }
function bad(res, msg='Bad request', status=400){ json(res, status, { error: msg }); }
function body(req){
  return new Promise((resolve, reject) => {
    let data='';
    req.on('data', chunk => { data += chunk; if(data.length > 1_000_000){ req.destroy(); reject(new Error('too large')); } });
    req.on('end', () => { try{ resolve(data ? JSON.parse(data) : {}); } catch(e){ reject(e); } });
    req.on('error', reject);
  });
}
function limited(req, key){
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'local';
  const k = `${ip}:${key}`; const t = Date.now(); const item = rate.get(k) || { n:0, reset:t+60_000 };
  if(t > item.reset){ item.n = 0; item.reset = t + 60_000; }
  item.n++; rate.set(k, item); return item.n > 20;
}
function sanitizeUser(u){
  if(!u) return null;
  const { passwordHash, salt, ...safe } = u;
  return safe;
}
function getSession(req){
  const d = db(); const sid = parseCookies(req)[COOKIE]; if(!sid) return { d };
  const session = d.sessions.find(s => s.id === sid && new Date(s.expiresAt) > new Date());
  if(!session) return { d };
  const user = d.users.find(u => u.id === session.userId);
  return { d, session, user };
}
function requireAuth(req, res, roles=null){
  const ctx = getSession(req);
  if(!ctx.user){ json(res, 401, { error:'Login required' }); return null; }
  if(roles && !roles.includes(ctx.user.role)){ json(res, 403, { error:'Not allowed' }); return null; }
  if(['POST','PUT','PATCH','DELETE'].includes(req.method) && !req.url.startsWith('/api/auth/')){
    const token = req.headers['x-csrf-token'];
    if(!token || token !== ctx.session.csrf){ json(res, 403, { error:'Security token missing' }); return null; }
  }
  return ctx;
}
function audit(d, userId, action, details={}){ d.audit.unshift({ id:id('audit'), userId, action, details, at: now() }); d.audit = d.audit.slice(0, 1000); }
function codeFor(seed){
  const h = crypto.createHash('sha256').update(String(seed).toLowerCase()).digest('hex').slice(0, 8);
  return 'ML-' + parseInt(h, 16).toString(36).toUpperCase().slice(0,6).padStart(6,'0');
}
function suggestRole(p={}){
  const skills = (p.skills || []).join(' ');
  if(p.path === 'Circle organizer' || /Organizing|Events/.test(skills)) return 'Circle Organizer';
  if(p.path === 'Builder' || /Technology|Media/.test(skills)) return 'Builder';
  if(p.path === 'Community partner' || p.circlePath === 'Bring a group') return 'Community Partner';
  if(/Legal|Business|Fundraising/.test(skills)) return 'Formation Support';
  return 'Founding Citizen';
}
function circleStatus(p={}){
  const loc = (p.location || 'your area').trim();
  if(p.circlePath === 'Start a Circle') return `Starter path opened for ${loc}`;
  if(p.circlePath === 'Bring a group') return `Group formation path opened for ${loc}`;
  if(['7-20','21-50','51+'].includes(p.groupSize)) return `Circle-ready group forming in ${loc}`;
  if(p.circlePath === 'Online first') return 'Online-first founding path opened';
  return `Matching you with people near ${loc}`;
}
function missionsFor(profile={}){
  const role = profile.suggestedRole || suggestRole(profile);
  const base = ['Share your invite with 3 people', 'Add one community need to your Values Agenda', 'Save your first assembly RSVP'];
  if(role === 'Circle Organizer') return ['Identify 3 people to invite','Choose a possible meeting place','Save your first assembly RSVP','Add one community need to your Values Agenda','Share your invite with 3 people'];
  if(role === 'Builder') return ['List what you can build or create','Share your invite with 3 people','Add one community need to your Values Agenda','Save your first assembly RSVP'];
  if(role === 'Community Partner') return ['Add your organization or group name','Invite your community contact','Save your first assembly RSVP','Add one community need to your Values Agenda'];
  if(role === 'Formation Support') return ['Choose your support lane','Add one community need to your Values Agenda','Share your invite with 3 people','Save your first assembly RSVP'];
  return base;
}
function enhanceProfile(input){
  const p = { ...input };
  p.priorities = Array.isArray(p.priorities) ? p.priorities : [];
  p.skills = Array.isArray(p.skills) ? p.skills : [];
  p.pledge = Array.isArray(p.pledge) ? p.pledge : [];
  p.code = p.code || codeFor(`${p.email}|${p.location}|${p.circlePath}`);
  p.suggestedRole = suggestRole(p);
  p.circleStatus = circleStatus(p);
  p.status = p.status || 'Onboarded';
  p.inviteLink = p.inviteLink || `/onboarding.html?invite=${encodeURIComponent(p.code)}`;
  return p;
}
function serveStatic(req, res, pathname){
  const routeMap = { '/':'index.html', '/login':'login.html', '/onboarding':'onboarding.html', '/citizen':'citizen.html', '/admin':'admin.html' };
  let file = routeMap[pathname] || pathname.replace(/^\//,'');
  const full = path.normalize(path.join(PUBLIC, file));
  if(!full.startsWith(PUBLIC)) return notFound(res);
  if((file === 'citizen.html')){ const ctx=getSession(req); if(!ctx.user) return redirect(res, '/login.html?next=/citizen'); }
  if((file === 'admin.html')){ const ctx=getSession(req); if(!ctx.user) return redirect(res, '/login.html?next=/admin'); if(!['admin','organizer'].includes(ctx.user.role)) return redirect(res, '/citizen'); }
  fs.readFile(full, (err, data) => {
    if(err) return notFound(res);
    const ext = path.extname(full).toLowerCase();
    send(res, 200, data, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-store' : 'public, max-age=3600' });
  });
}

async function api(req, res, pathname){
  if(pathname === '/api/auth/register' && req.method === 'POST'){
    if(limited(req,'register')) return bad(res, 'Too many attempts', 429);
    const b = await body(req); const email = normEmail(b.email); const password = String(b.password || '');
    if(!email || !/^\S+@\S+\.\S+$/.test(email)) return bad(res, 'Valid email required');
    if(password.length < 10) return bad(res, 'Password must be at least 10 characters');
    if(!b.name || !b.location) return bad(res, 'Name and location are required');
    const d = db(); if(d.users.some(u => u.email === email)) return bad(res, 'Account already exists', 409);
    const hp = hashPassword(password); const profile = enhanceProfile({ ...b, email });
    const firstUserAdmin = process.env.FIRST_USER_ADMIN === 'true' && d.users.length === 0;
    const user = { id:id('user'), email, passwordHash:hp.hash, salt:hp.salt, role:firstUserAdmin?'admin':'citizen', verified:false, createdAt:now(), updatedAt:now(), profile, missionState:{} };
    d.users.push(user); audit(d, user.id, 'registered', { role:user.role });
    const csrf = crypto.randomBytes(24).toString('hex'); const sid = crypto.randomBytes(32).toString('hex');
    d.sessions.push({ id:sid, userId:user.id, csrf, createdAt:now(), expiresAt:new Date(Date.now()+SESSION_DAYS*864e5).toISOString() });
    save(d);
    return json(res, 201, { user:sanitizeUser(user), csrf }, { 'Set-Cookie': cookieHeader(COOKIE, sid, { maxAge: SESSION_DAYS*86400 }) });
  }
  if(pathname === '/api/auth/login' && req.method === 'POST'){
    if(limited(req,'login')) return bad(res, 'Too many attempts', 429);
    const b = await body(req); const email = normEmail(b.email); const d = db(); const user = d.users.find(u => u.email === email);
    if(!user || !checkPassword(String(b.password || ''), user.salt, user.passwordHash)) return bad(res, 'Invalid login', 401);
    const csrf = crypto.randomBytes(24).toString('hex'); const sid = crypto.randomBytes(32).toString('hex');
    d.sessions.push({ id:sid, userId:user.id, csrf, createdAt:now(), expiresAt:new Date(Date.now()+SESSION_DAYS*864e5).toISOString() });
    audit(d, user.id, 'login'); save(d);
    return json(res, 200, { user:sanitizeUser(user), csrf }, { 'Set-Cookie': cookieHeader(COOKIE, sid, { maxAge: SESSION_DAYS*86400 }) });
  }
  if(pathname === '/api/auth/logout' && req.method === 'POST'){
    const ctx = getSession(req); if(ctx.session){ ctx.d.sessions = ctx.d.sessions.filter(s => s.id !== ctx.session.id); save(ctx.d); }
    return json(res, 200, { ok:true }, { 'Set-Cookie': cookieHeader(COOKIE, '', { maxAge: 0 }) });
  }
  if(pathname === '/api/me' && req.method === 'GET'){
    const ctx = requireAuth(req,res); if(!ctx) return;
    return json(res, 200, { user:sanitizeUser(ctx.user), csrf:ctx.session.csrf });
  }
  if(pathname === '/api/dashboard' && req.method === 'GET'){
    const ctx = requireAuth(req,res); if(!ctx) return; const userId = ctx.user.id;
    return json(res, 200, { user:sanitizeUser(ctx.user), agenda:ctx.d.agenda.filter(a=>a.userId===userId), assembly:ctx.d.assemblies[userId] || {}, invites:ctx.d.invites.filter(i=>i.userId===userId), events:ctx.d.events, missions:missionsFor(ctx.user.profile), missionState:ctx.user.missionState || {} });
  }
  if(pathname === '/api/profile' && req.method === 'PUT'){
    const ctx = requireAuth(req,res); if(!ctx) return; const b = await body(req);
    ctx.user.profile = enhanceProfile({ ...ctx.user.profile, ...b, email:ctx.user.email }); ctx.user.updatedAt = now(); audit(ctx.d, ctx.user.id, 'profile.updated'); save(ctx.d);
    return json(res, 200, { user:sanitizeUser(ctx.user) });
  }
  if(pathname === '/api/agenda' && req.method === 'POST'){
    const ctx = requireAuth(req,res); if(!ctx) return; const b = await body(req); if(!b.text) return bad(res,'Agenda text required');
    const item = { id:id('agenda'), userId:ctx.user.id, priority:b.priority || 'General', text:String(b.text).slice(0,1000), createdAt:now() };
    ctx.d.agenda.unshift(item); audit(ctx.d, ctx.user.id, 'agenda.created', { id:item.id }); save(ctx.d); return json(res, 201, { item });
  }
  if(pathname.startsWith('/api/agenda/') && req.method === 'DELETE'){
    const ctx = requireAuth(req,res); if(!ctx) return; const itemId = pathname.split('/').pop();
    ctx.d.agenda = ctx.d.agenda.filter(a => !(a.id === itemId && a.userId === ctx.user.id)); audit(ctx.d, ctx.user.id, 'agenda.deleted', { id:itemId }); save(ctx.d); return json(res, 200, { ok:true });
  }
  if(pathname === '/api/assembly' && req.method === 'PUT'){
    const ctx = requireAuth(req,res); if(!ctx) return; const b = await body(req);
    ctx.d.assemblies[ctx.user.id] = { rsvp:b.rsvp || '', availability:b.availability || '', note:String(b.note || '').slice(0,1000), savedAt:now() };
    audit(ctx.d, ctx.user.id, 'assembly.saved'); save(ctx.d); return json(res, 200, { assembly:ctx.d.assemblies[ctx.user.id] });
  }
  if(pathname === '/api/missions' && req.method === 'PUT'){
    const ctx = requireAuth(req,res); if(!ctx) return; const b = await body(req);
    ctx.user.missionState = ctx.user.missionState || {}; ctx.user.missionState[String(b.mission)] = !!b.done; audit(ctx.d, ctx.user.id, 'mission.updated', { mission:b.mission, done:!!b.done }); save(ctx.d); return json(res, 200, { missionState:ctx.user.missionState });
  }
  if(pathname === '/api/invites' && req.method === 'POST'){
    const ctx = requireAuth(req,res); if(!ctx) return; const b = await body(req); if(!b.name) return bad(res,'Name required');
    const invite = { id:id('invite'), userId:ctx.user.id, name:String(b.name).slice(0,120), contact:String(b.contact||'').slice(0,180), sent:false, joined:false, createdAt:now() };
    ctx.d.invites.push(invite); audit(ctx.d, ctx.user.id, 'invite.created'); save(ctx.d); return json(res, 201, { invite });
  }
  if(pathname.startsWith('/api/invites/') && req.method === 'PUT'){
    const ctx = requireAuth(req,res); if(!ctx) return; const b = await body(req); const invite = ctx.d.invites.find(i=>i.id===pathname.split('/').pop() && i.userId===ctx.user.id); if(!invite) return notFound(res);
    if('sent' in b) invite.sent = !!b.sent; if('joined' in b) invite.joined = !!b.joined; invite.updatedAt = now(); audit(ctx.d, ctx.user.id, 'invite.updated'); save(ctx.d); return json(res, 200, { invite });
  }
  if(pathname.startsWith('/api/invites/') && req.method === 'DELETE'){
    const ctx = requireAuth(req,res); if(!ctx) return; const inviteId = pathname.split('/').pop(); ctx.d.invites = ctx.d.invites.filter(i => !(i.id===inviteId && i.userId===ctx.user.id)); audit(ctx.d, ctx.user.id, 'invite.deleted'); save(ctx.d); return json(res, 200, { ok:true });
  }
  if(pathname === '/api/admin/citizens' && req.method === 'GET'){
    const ctx = requireAuth(req,res,['admin','organizer']); if(!ctx) return;
    const citizens = ctx.d.users.map(u => sanitizeUser(u));
    const stats = { total:citizens.length, onboarded:citizens.filter(u=>u.profile?.status==='Onboarded').length, active:citizens.filter(u=>u.profile?.status==='Active citizen').length, organizers:citizens.filter(u=>/Organizer/.test(u.profile?.suggestedRole||'') || u.role==='organizer').length };
    return json(res, 200, { citizens, stats, events:ctx.d.events });
  }
  if(pathname.startsWith('/api/admin/citizens/') && req.method === 'PUT'){
    const ctx = requireAuth(req,res,['admin']); if(!ctx) return; const b = await body(req); const user = ctx.d.users.find(u=>u.id===pathname.split('/').pop()); if(!user) return notFound(res);
    user.profile = { ...user.profile, status:b.status || user.profile.status, assignedCircle:b.assignedCircle || user.profile.assignedCircle || '', circleStatus:b.circleStatus || user.profile.circleStatus };
    if(['citizen','organizer','admin'].includes(b.role)) user.role = b.role;
    user.updatedAt = now(); audit(ctx.d, ctx.user.id, 'admin.citizen.updated', { target:user.id }); save(ctx.d); return json(res, 200, { user:sanitizeUser(user) });
  }
  if(pathname === '/api/admin/events' && req.method === 'POST'){
    const ctx = requireAuth(req,res,['admin','organizer']); if(!ctx) return; const b = await body(req); if(!b.title) return bad(res,'Title required');
    const event = { id:id('event'), title:String(b.title).slice(0,160), date:String(b.date||''), location:String(b.location||''), notes:String(b.notes||''), createdBy:ctx.user.id, createdAt:now() };
    ctx.d.events.unshift(event); audit(ctx.d, ctx.user.id, 'event.created'); save(ctx.d); return json(res, 201, { event });
  }
  return notFound(res);
}

const server = http.createServer(async (req, res) => {
  try{
    const u = new URL(req.url, `http://${req.headers.host}`);
    if(u.pathname.startsWith('/api/')) return await api(req, res, u.pathname);
    return serveStatic(req, res, u.pathname);
  }catch(e){ console.error(e); json(res, 500, { error:'Server error' }); }
});
server.listen(PORT, () => console.log(`MiLyfe platform running at http://localhost:${PORT}`));
